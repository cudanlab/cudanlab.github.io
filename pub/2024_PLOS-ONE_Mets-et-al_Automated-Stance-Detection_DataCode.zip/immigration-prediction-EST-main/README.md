


Supplementary material for article "Automated stance detection in complex topics and small languages: the challenging case of immigration in polarizing news media".
Data and code are free to use as it is.

If used, please cite the article: [to be added]


Includes:


**CODE:** Jupyter notebook to train Large Language Model and applying it for prediction. Ready to use in Google Colab.

**DATASET:** 
1) Annotated datased of immigration related sentences in Estonian.
2) All immigration related sentences in our dataset.

   
 
 Annotated dataset description:
    
    Contains 7435 sentences with annotations. 3261 are Against, Neutral and Supportive categories and rest are nonevaluative (MH)

    MH - nonevaluative (ambiguous)
    1-2 - Against
    3 - Neutral
    4-5 Supportive

    stanceConsolidated - Annotated stances from two annotators plus taking into consideration consolidations from one of the authors. Used for predictions in the article. 
